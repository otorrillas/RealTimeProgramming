/*
	LiftWorker.cpp
	Real-Time Programming Project
	Authors: @bomanmaster @otorrillas
*/

#include "ElevInterface.hpp"
#include "PanelInterface.hpp"

#define OPT_DELAY 175000
#define DOOR_DELAY 2000

#include <vector>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <iostream>

using namespace std;

ElevInterface elevInt = ElevInterface();
PanelInterface panelInt = PanelInterface();

bool liftpause = false;
ElevInterface::tag_elev_motor_direction direction = ElevInterface::DIRN_STOP;

void floor_pause() {
	liftpause = true;
	usleep(OPT_DELAY);
	direction = ElevInterface::DIRN_STOP;
	elevInt.set_motor_direction(ElevInterface::DIRN_STOP);
	panelInt.set_door_open_lamp(1);
	usleep(DOOR_DELAY);
	while(panelInt.get_obstruction_signal() == 1);
}

void recovery_restore() {

}

int main(int argc,char *argv[]) {
	
	cout << "Worker started" << endl;
	int currentFloor = elevInt.get_floor_sensor_signal();
	int prevFloor = 0;

	if(argc > 1 and argv[1] == "R") {
		recovery_restore();
	}

	int mode = 0;
	
	vector<bool> requestedFloors(N_FLOORS, false);


	while(mode != 2) {

		int i = -1, num;
		ifstream workerFile("worker_info.txt");
		while(workerFile >> num) {
			cout << "Num: " << num << endl;
			if(i == -1)
				mode = num;
			else {
				requestedFloors[i] = num;
				cout << "RequestedFloors[" << i << "]=" << requestedFloors[i] << endl;	
			}
			
			++i;
		}


		workerFile.close();

		currentFloor = elevInt.get_floor_sensor_signal();

		cout << "currentFloor: " << currentFloor << endl;

		// Direction
		if(currentFloor != -1) {
			panelInt.set_floor_indicator(currentFloor);
			prevFloor = currentFloor;
			i = currentFloor+1;
		} 
		else
			i = prevFloor+1;

		bool dirUp = false;
		for(; i < N_FLOORS; ++i)
				dirUp = dirUp or requestedFloors[i];
			
		if(dirUp) {
			direction = ElevInterface::DIRN_UP;
			panelInt.set_door_open_lamp(0);
		}
		else if(!liftpause) {
			direction = ElevInterface::DIRN_DOWN;
			panelInt.set_door_open_lamp(0);
		}
		

		
		if(currentFloor != -1 and requestedFloors[currentFloor]) {
			cout << "We have arrived to the floor" << endl;
			floor_pause();
			requestedFloors[currentFloor] = false;
		}

		bool reqFloorActive = false;
		for(bool b : requestedFloors)
			reqFloorActive = reqFloorActive or b;

		/*
		if(reqFloorActive)
			liftpause = false;
		*/
		if(!reqFloorActive) {
			if(mode == 0) {
				while(liftpause) {
					for(i = 0; i < N_FLOORS; i++) { 
						if(panelInt.get_button_signal(PanelInterface::BUTTON_COMMAND, i) == 1) {
							cout << "HeisPanel button pressed: " << i << endl;
							requestedFloors[i] = true;
							liftpause = false;
							if(i > currentFloor)
								panelInt.set_button_lamp(PanelInterface::BUTTON_CALL_UP, currentFloor ,0);
							else
								panelInt.set_button_lamp(PanelInterface::BUTTON_CALL_DOWN, currentFloor, 0);
						}
					}
				}
				mode = 1;
			}
			else if(mode == 1) {
				mode = 2;
			}
		}

		

		elevInt.set_motor_direction(direction);

		ofstream infoWriter;
        infoWriter.open ("worker_info.txt",  ofstream::out |  ofstream::trunc);
        infoWriter << mode;
        for(bool b : requestedFloors) {
        	cout << b << endl;
        	infoWriter << " " << b;
        }
        infoWriter.close();

	}

	direction = ElevInterface::DIRN_STOP;
	elevInt.set_motor_direction(direction);


}
