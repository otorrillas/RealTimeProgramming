#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <string>
#include <iostream>

using namespace std;

bool isAlive(){
    int m, m_recv;

    m_recv = system("pgrep ClientMain");
    m = system("pgrep ClientListener");

    cout << "Result: " << m_recv << ": " << m << endl;

    return ((m == 0) and (m_recv == 0));

}

int main(int argc,char *argv[]){

    if(argc < 2)
        perror("Usage:\n\tClientRunner IP_ADDRESS");

    string ip_addres = argv[1];
    

    pid_t pid;

    pid = fork();
    if (pid == 0) {
        char *argv2[] = {"ClientMain", "-x", "./ClientMain", argv[1], NULL};
        int rc2 = execv("/usr/bin/gnome-terminal",argv2);
        if (rc2 == -1 )
            perror("Error at spawning ClientMain");

    }

    sleep(2);
    while(1){

        if (not isAlive()){

            system("pkill -9 ClientMain");
            system("pkill -9 ClientListener");
            string reccall = "/usr/bin/gnome-terminal -x ./ClientMain " + ip_addres + " R";
            system(reccall.c_str());

            break;

        }
        sleep(1);

    }
    exit(0);


    return 0;
}
