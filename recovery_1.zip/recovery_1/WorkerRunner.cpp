#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <iostream>

using namespace std;

bool isAlive(){
    
    int m;
    m = system("pgrep ClientListener");
    cout << "Result: " << m << endl;

    return (m == 0);
}

int main(){
    


    int ret;
    pid = fork();
    if (pid == 0) {
        ret = system("./LiftWorker");
    }


    sleep(5);
    while(1){

        if(not isAlive()) {

            if (WEXITSTATUS(ret) == 0)
                exit(0);
            else
                ret = system("./LiftWorker");
        }
        sleep(1);

    }
    exit(0);


    return 0;
}
