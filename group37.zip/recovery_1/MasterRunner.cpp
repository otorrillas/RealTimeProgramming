#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <iostream>

using namespace std;

bool isAlive(){
    int m, m_recv;

    m_recv = system("pgrep MasterMain");
    m = system("pgrep MasterListener");

    cout << "Result: " << m_recv << ": " << m << endl;

    return ((m == 0) and (m_recv == 0));

}

int main(int argc, char**argv[]){


    pid_t pid;

    pid = fork();
    if (pid == 0) {

        if(argc > 1) {

            char *argv2[] = {"MasterMain", "-x", "./MasterMain", "R", NULL};
            int rc2 = execv("/usr/bin/gnome-terminal",argv2);
            if (rc2 == -1 )
                perror("Error at spawning MasterMain with Recovery mode");
        }
        else {
            char *argv2[] = {"MasterMain", "-x", "./MasterMain", NULL};
            int rc2 = execv("/usr/bin/gnome-terminal",argv2);
            if (rc2 == -1 )
                perror("Error at spawning MasterMain");
        }
        

        

    }

    sleep(2);
    while(1){

        if (not isAlive()){

            system("pkill -9 MasterMain");
            system("pkill -9 MasterListener");

            system("gnome-terminal -x ./MasterRunner R");

            
            break;

        }
        sleep(1);

    }
    exit(0);


    return 0;
}
