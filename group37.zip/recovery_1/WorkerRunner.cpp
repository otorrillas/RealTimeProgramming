#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <fstream>
#include <iostream>

using namespace std;

bool isAlive(){
    
    int m;
    m = system("pgrep LiftWorker");
    cout << "Result: " << m << endl;

    return (m == 0);
}

bool exitedOkay() {
    ifstream workerFile("worker_info.txt");
    if(workerFile.is_open()) {
        int state;
        workerFile >> state;
        
        return (state == 2);
    }
    return false;
    
}

int main(){
    
    pid_t pid;
    int ret;
    pid = fork();
    if (pid == 0) {
        char *argv2[] = {"LiftWorker", "-x", "./LiftWorker", NULL};
        int rc2 = execv("/usr/bin/gnome-terminal",argv2);
        if (rc2 == -1 )
            perror("Error at spawning LiftWorker");
    }


    sleep(2);
    while(1){

        if(not isAlive()) {
            if(exitedOkay())
                exit(0);
            else {
                system("./WorkerRunner");
            }
            
        }
        sleep(1);

    }
    exit(0);


    return 0;
}
